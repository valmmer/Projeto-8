// Geração de PDF via html2canvas + jsPDF (A4, multi-página) com cortes inteligentes
// - respeita margens reais ABNT/Modern
// - evita cortar dentro de .no-split / .keep-with-next
// - evita começar página nova exatamente em títulos (h1/h2/h3/.sec)
//
// Observação: as classes .no-split e .keep-with-next já existem no seu print.css.
// Basta garantir que os blocos relevantes (títulos + 1º parágrafo/lista) estejam marcados.

import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

type ExportOptions = {
  fileName?: string;
  scale?: number;
  imageQuality?: number;
  pageBackground?: string;
};

const A4_W_MM = 210;
const A4_H_MM = 297;

// --- utils básicos -----------------------------------------------------------
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const mm = (mm: number, pxPerMm: number) => Math.round(mm * pxPerMm);

function sliceCanvas(
  source: HTMLCanvasElement,
  topPx: number,
  heightPx: number,
) {
  const slice = document.createElement('canvas');
  slice.width = source.width;
  slice.height = Math.max(1, Math.min(heightPx, source.height - topPx));
  const ctx = slice.getContext('2d')!;
  ctx.drawImage(
    source,
    0,
    topPx,
    source.width,
    slice.height,
    0,
    0,
    source.width,
    slice.height,
  );
  return slice;
}

function detectTemplate(pageEl: HTMLElement): 'abnt' | 'modern' {
  return pageEl.classList.contains('abnt') || pageEl.dataset.template === 'abnt'
    ? 'abnt'
    : 'modern';
}

// Habilita modo captura: zera o padding do preview (margem é aplicada pelo PDF)
function prepareForPdf(pageEl: HTMLElement, on: boolean) {
  if (!pageEl) return;
  if (on) {
    pageEl.classList.add('for-pdf');
    const prev =
      pageEl.getAttribute('data-prev-padding') ?? pageEl.style.padding ?? '';
    pageEl.setAttribute('data-prev-padding', prev);
    pageEl.style.padding = '0';
  } else {
    pageEl.classList.remove('for-pdf');
    const prev = pageEl.getAttribute('data-prev-padding') ?? '';
    pageEl.style.padding = prev;
    pageEl.removeAttribute('data-prev-padding');
  }
}

// Converte boundingClientRect() (em CSS px) para coordenadas no canvas
function cssToCanvasY(
  cssY: number,
  pageEl: HTMLElement,
  canvas: HTMLCanvasElement,
) {
  const scaleY = canvas.height / pageEl.clientHeight; // altura em px CSS -> px canvas
  return cssY * scaleY;
}

// Mapeia zonas a evitar (no-split / keep-with-next / headings)
function buildAvoidZonesPx(pageEl: HTMLElement, canvas: HTMLCanvasElement) {
  const zones: Array<[number, number]> = [];

  const addZone = (topCss: number, bottomCss: number, padCss = 8) => {
    const t = cssToCanvasY(topCss - padCss, pageEl, canvas);
    const b = cssToCanvasY(bottomCss + padCss, pageEl, canvas);
    zones.push([Math.max(0, t), Math.max(0, b)]);
  };

  const selNoSplit = Array.from(
    pageEl.querySelectorAll<HTMLElement>('.no-split'),
  );
  for (const el of selNoSplit) {
    const r = el.getBoundingClientRect();
    addZone(r.top, r.bottom, 10);
  }

  // Keep-with-next: pega elemento + próximo irmão direto
  const selKeep = Array.from(
    pageEl.querySelectorAll<HTMLElement>('.keep-with-next'),
  );
  for (const el of selKeep) {
    const r = el.getBoundingClientRect();
    const next = (
      el.nextElementSibling as HTMLElement | null
    )?.getBoundingClientRect();
    const bottom = next ? next.bottom : r.bottom + 24; // fallback
    addZone(r.top, bottom, 10);
  }

  // Headings comuns (inclui seu .sec)
  const headings = Array.from(
    pageEl.querySelectorAll<HTMLElement>('h1,h2,h3,.sec'),
  );
  for (const h of headings) {
    const r = h.getBoundingClientRect();
    // zona pequena no título + primeira linha seguinte (~32px)
    addZone(r.top, r.top + 32, 6);
  }

  // Normaliza (merge) zonas sobrepostas
  zones.sort((a, b) => a[0] - b[0]);
  const merged: Array<[number, number]> = [];
  for (const z of zones) {
    if (!merged.length || z[0] > merged[merged.length - 1][1] + 2) {
      merged.push([...z] as [number, number]);
    } else {
      merged[merged.length - 1][1] = Math.max(
        merged[merged.length - 1][1],
        z[1],
      );
    }
  }
  return merged;
}

function isInsideZones(yPx: number, zones: Array<[number, number]>) {
  for (const [a, b] of zones) if (yPx >= a && yPx <= b) return true;
  return false;
}

// Ajusta corte para fora das zonas a evitar e tenta não começar a página em título
function findSmartCutY(
  idealCutPx: number,
  topLimitPx: number,
  canvas: HTMLCanvasElement,
  zones: Array<[number, number]>,
  pxPerMmY: number,
) {
  // guardas de qualidade visual
  const step = Math.max(1, Math.round(pxPerMmY * 0.5)); // ~0.5 mm por passo
  const minSlicePx = Math.round(pxPerMmY * 20); // nunca deixar uma página com menos de ~20mm

  let y = idealCutPx;

  // 1) Evita cortar dentro das zonas mapeadas
  let safety = 4000; // evita loops; suficiente para conteúdos longos
  while (
    isInsideZones(y, zones) &&
    y - topLimitPx > minSlicePx &&
    safety-- > 0
  ) {
    y -= step;
  }

  // 2) Se ainda vamos começar a próxima página "muito em cima" (<= ~6mm do topo),
  // recua o corte um pouco para dar respiro visual
  const MIN_TOP_PAD_MM = 6;
  const minTopPadPx = Math.round(pxPerMmY * MIN_TOP_PAD_MM);
  if (y - topLimitPx > minSlicePx && idealCutPx - y < minTopPadPx) {
    y = clamp(idealCutPx - minTopPadPx, topLimitPx + minSlicePx, idealCutPx);
  }

  // Piso final de segurança
  if (y - topLimitPx < minSlicePx)
    y = clamp(topLimitPx + minSlicePx, topLimitPx, idealCutPx);

  return y;
}

// --- API principal -----------------------------------------------------------
export async function elementToPDF(
  target: HTMLElement,
  opts: ExportOptions = {},
) {
  const {
    fileName = 'curriculo',
    scale,
    imageQuality = 0.95,
    pageBackground = '#FFFFFF',
  } = opts;

  const pages: HTMLElement[] = target.classList.contains('page')
    ? [target]
    : Array.from(target.querySelectorAll<HTMLElement>('.page'));

  if (!pages.length)
    throw new Error('Não encontrei elementos com classe ".page".');

  const dpr = window.devicePixelRatio || 1;
  const finalScale = scale ?? Math.min(Math.max(dpr * 1.5, 2), 3);

  const pdf = new jsPDF({ unit: 'mm', format: 'a4', compress: true });
  let first = true;

  for (const pageEl of pages) {
    const tpl = detectTemplate(pageEl);
    const margins =
      tpl === 'abnt'
        ? { top: 30, right: 20, bottom: 20, left: 30 }
        : { top: 12, right: 12, bottom: 12, left: 12 };

    const innerWmm = A4_W_MM - (margins.left + margins.right);
    const innerHmm = A4_H_MM - (margins.top + margins.bottom);

    // Captura somente a área útil (padding 0)
    prepareForPdf(pageEl, true);
    const canvas = await html2canvas(pageEl, {
      scale: finalScale,
      backgroundColor: pageBackground,
      logging: false,
      useCORS: true,
      allowTaint: true,
      imageTimeout: 20000,
      windowWidth: pageEl.scrollWidth,
      windowHeight: pageEl.scrollHeight,
    });
    prepareForPdf(pageEl, false);

    // Fatores px/mm da ÁREA ÚTIL
    const pxPerMmY = canvas.height / innerHmm;
    // Altura da fatia por página, em px (área útil)
    const innerHeightPx = mm(innerHmm, pxPerMmY);
    const overlapPx = Math.max(1, Math.round(pxPerMmY * 0.5)); // ~0.5mm de sobreposição

    // Constrói zonas a evitar em coordenadas do canvas
    const avoidZones = buildAvoidZonesPx(pageEl, canvas);

    let topPx = 0;
    while (topPx < canvas.height - 1) {
      const idealCut = Math.min(canvas.height, topPx + innerHeightPx);
      // Encontrar corte “inteligente” para essa página
      const cutY = findSmartCutY(idealCut, topPx, canvas, avoidZones, pxPerMmY);
      const slice = sliceCanvas(canvas, topPx, cutY - topPx);
      const img = slice.toDataURL('image/jpeg', imageQuality);

      if (!first) pdf.addPage();
      first = false;

      // Preenche a área útil (evita “bordas” escuras de viewer)
      pdf.setFillColor(255, 255, 255);
      pdf.rect(margins.left, margins.top, innerWmm, innerHmm, 'F');

      // Desenha a fatia ocupando TODA a área útil
      pdf.addImage(
        img,
        'JPEG',
        margins.left,
        margins.top,
        innerWmm,
        innerHmm,
        undefined,
        'FAST',
      );

      // Avança para próxima página, com overlap anti-linha
      topPx = cutY - overlapPx;
    }
  }

  pdf.save(`${fileName}.pdf`);
}

export async function elementToPNG(
  pageEl: HTMLElement,
  fileName = 'curriculo',
) {
  prepareForPdf(pageEl, true);
  const dpr = window.devicePixelRatio || 1;
  const canvas = await html2canvas(pageEl, {
    scale: Math.min(Math.max(dpr * 1.5, 2), 3),
    backgroundColor: '#FFFFFF',
    logging: false,
    useCORS: true,
    allowTaint: true,
    windowWidth: pageEl.scrollWidth,
    windowHeight: pageEl.scrollHeight,
  });
  prepareForPdf(pageEl, false);

  const data = canvas.toDataURL('image/png');
  const a = document.createElement('a');
  a.href = data;
  a.download = `${fileName}.png`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
