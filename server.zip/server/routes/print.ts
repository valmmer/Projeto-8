// server/routes/print.ts
import { Router } from 'express';

export const printRouter = Router();

/**
 * POST /api/print/pdf
 * Body:
 *  {
 *    url?: string;      // opção 1: abrir a URL pública (recomendado)
 *    html?: string;     // opção 2: HTML inline (injeta <base> p/ assets)
 *    fileName?: string; // nome do arquivo sem .pdf (default: "curriculo")
 *  }
 *
 * Observação:
 *  - As margens reais vêm do CSS (@page abnt/moder n).
 *  - Aqui deixamos margin: 0 e preferCSSPageSize: true para respeitar o @page.
 */
printRouter.post('/pdf', async (req, res) => {
  const { url, html, fileName } = req.body ?? {};
  if (!url && !html) {
    return res.status(400).json({ error: 'Envie "url" ou "html".' });
  }

  // Import dinâmico (funciona em CJS/ESM sem quebrar build)
  const { default: puppeteer } = await import('puppeteer');

  // Base para assets quando vier HTML inline
  // Tente usar o Origin do request, ou variável PRINT_BASE_URL (ex.: http://localhost:5173/)
  const baseHref = req.get('origin') || process.env.PRINT_BASE_URL || '';

  const safeName = sanitizeFileName(fileName || 'curriculo') + '.pdf';

  let browser: any = null;
  try {
    browser = await puppeteer.launch({
      headless: true,
      // Em container/host sem sandbox:
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--font-render-hinting=none',
      ],
      // Se for usar o Chrome do sistema (ex.: Docker com chromium):
      executablePath: process.env.PUPPETEER_EXECUTABLE_PATH,
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 900, deviceScaleFactor: 1 });

    // Respeita @media print e @page
    await page.emulateMediaType('print');

    if (url) {
      await page.goto(url, { waitUntil: 'networkidle0', timeout: 60_000 });
    } else {
      const content = injectBase(String(html), baseHref);
      await page.setContent(content, { waitUntil: 'networkidle0' });
    }

    // Aguarda fontes e imagens terminarem de carregar
    await waitForImagesAndFonts(page);

    const pdf = await page.pdf({
      format: 'A4',
      printBackground: true,
      preferCSSPageSize: true, // ← respeita @page abnt/modern
      // Margem 0: @page do CSS manda nas margens
      margin: { top: '0mm', right: '0mm', bottom: '0mm', left: '0mm' },
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
    res.send(pdf);
  } catch (err: any) {
    console.error('[print] erro:', err);
    res.status(500).json({ error: err?.message ?? 'Erro ao gerar PDF' });
  } finally {
    if (browser) await browser.close();
  }
});

/* ---------------- helpers ---------------- */

function sanitizeFileName(s: string) {
  return String(s)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\-]+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function injectBase(html: string, baseHref: string) {
  if (!baseHref) return html;
  if (/<base\s/i.test(html)) return html; // já existe <base>
  if (/<head[\s>]/i.test(html)) {
    return html.replace(
      /<head(\s[^>]*)?>/i,
      (m) => `${m}\n<base href="${baseHref}">`,
    );
  }
  if (/<html(\s[^>]*)?>/i.test(html)) {
    return html.replace(
      /<html(\s[^>]*)?>/i,
      (m) => `${m}\n<head><base href="${baseHref}"></head>`,
    );
  }
  // HTML mínimo sem <html>/<head>
  return `<head><base href="${baseHref}"></head>${html}`;
}

async function waitForImagesAndFonts(page: import('puppeteer').Page) {
  await page.evaluate(async () => {
    const imgs = Array.from(document.images || []);
    await Promise.all(
      imgs.map(
        (img) =>
          new Promise<void>((resolve) => {
            if (img.complete) return resolve();
            img.addEventListener('load', () => resolve(), { once: true });
            img.addEventListener('error', () => resolve(), { once: true });
          }),
      ),
    );
    // @ts-ignore
    if (document?.fonts?.ready) {
      // @ts-ignore
      await document.fonts.ready;
    }
  });
}
