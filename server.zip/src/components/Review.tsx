// src/components/Review.tsx
// ----------------------------------------------------------------------------
// Painel de "Revisão Final"
// - Troca de template (Clássico ABNT | Modern Clean)
// - Imprimir (usa @media print do CSS)
// - Exportar PDF (local: html2canvas + jsPDF)
// - Exportar PNG
// - Exportar PDF via servidor (Puppeteer) -> /api/print/pdf (somente #cv-page)
// ----------------------------------------------------------------------------

import React, { useRef, useState } from 'react';
import ResumePreview, { type ResumeTemplateId } from './preview/ResumePreview';
import { elementToPDF, elementToPNG } from '../lib/pdf/export';
import { useResume } from '../state/ResumeContext';
import { downloadServerPDF } from '../lib/serverPrint';

type Props = {
  template: ResumeTemplateId;
  onTemplateChange: (t: ResumeTemplateId) => void;
};

// Slug para nome do arquivo (remove acentos e símbolos)
function slug(s: string) {
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\-]+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '');
}

// Localiza o elemento da página A4 dentro do wrapper
function getPageEl(wrap: HTMLElement | null): HTMLElement | null {
  if (!wrap) return null;
  return (
    wrap.querySelector<HTMLElement>('#cv-page') ??
    wrap.querySelector<HTMLElement>('.page') ??
    null
  );
}

export default function Review({ template, onTemplateChange }: Props) {
  const cvWrapRef = useRef<HTMLDivElement>(null);
  const [saving, setSaving] = useState(false);
  const { state } = useResume();

  /* -------------------- Exportar PDF (cliente) -------------------- */
  async function handleExportPDF() {
    if (saving) return;
    const page = getPageEl(cvWrapRef.current);
    if (!page) {
      alert('Não foi possível localizar o preview (#cv-page).');
      return;
    }
    try {
      setSaving(true);
      const nome = slug(state?.dados?.nome || 'Curriculo');
      await elementToPDF(page, {
        fileName: nome,
        // (as margens/cortes são definidos pelo export.ts; nada extra aqui)
      });
    } catch (e) {
      console.error('[pdf] erro:', e);
      alert('Não foi possível gerar o PDF agora.');
    } finally {
      setSaving(false);
    }
  }

  /* -------------------- Exportar PNG (cliente) -------------------- */
  async function handleExportPNG() {
    if (saving) return;
    const page = getPageEl(cvWrapRef.current);
    if (!page) return;
    try {
      setSaving(true);
      const nome = slug(state?.dados?.nome || 'Curriculo');
      await elementToPNG(page, nome);
    } catch (e) {
      console.error('[png] erro:', e);
      alert('Não foi possível gerar a imagem agora.');
    } finally {
      setSaving(false);
    }
  }

  /* -------------------- Exportar PDF (servidor / Puppeteer) -------------------- */
  async function handleServerPDF() {
    if (saving) return;
    try {
      setSaving(true);
      const nome = slug(state?.dados?.nome || 'Curriculo');

      // Alguns projetos expõem downloadServerPDF(url) e outros (url, opts).
      // Tenta com (url, opts) e, se falhar por tipo, cai para (url).
      try {
        await (
          downloadServerPDF as unknown as (
            url?: string,
            opts?: any,
          ) => Promise<void>
        )(window.location.href, { fileName: nome, selector: '#cv-page' });
      } catch {
        await (downloadServerPDF as unknown as (url?: string) => Promise<void>)(
          window.location.href,
        );
      }
    } catch (e) {
      console.error('[server-pdf] erro:', e);
      alert('Falha ao gerar PDF no servidor.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="card" aria-busy={saving}>
      {/* Toolbar */}
      <div className="preview-toolbar">
        <label className="text-sm text-slate-600 mr-2">Modelo</label>
        <select
          className="input !h-8 !py-0 mr-3"
          value={template}
          onChange={(e) =>
            onTemplateChange(e.currentTarget.value as ResumeTemplateId)
          }
          title="Modelo de currículo"
          disabled={saving}
        >
          {/* Ajuste o value conforme seu tipo ResumeTemplateId:
             - Se o seu tipo é 'classico' | 'clean', mantenha 'clean' aqui.
             - Se já migrou para 'moderno', troque 'clean' por 'moderno'. */}
          <option value="classico">Clássico ABNT</option>
          <option value="clean">Moderno Clean</option>
        </select>

        <button
          className="btn btn-outline"
          onClick={() => window.print()}
          disabled={saving}
          title="Imprimir / Salvar como PDF (nativo)"
        >
          Imprimir
        </button>

        <button
          className="btn btn-primary"
          onClick={handleExportPDF}
          disabled={saving}
          title="Gerar PDF via html2canvas + jsPDF"
        >
          {saving ? 'Gerando…' : 'Gerar PDF'}
        </button>

        <button
          className="btn btn-secondary"
          onClick={handleServerPDF}
          disabled={saving}
          title="Gerar via servidor (Puppeteer)"
        >
          {saving ? 'Gerando…' : 'Gerar PDF (Servidor)'}
        </button>

        <button
          className="btn"
          onClick={handleExportPNG}
          disabled={saving}
          title="Exportar visual como PNG"
        >
          {saving ? 'Gerando…' : 'Exportar PNG'}
        </button>
      </div>

      {/* Canvas do preview */}
      <div className="preview-body">
        <div
          ref={cvWrapRef}
          className="preview-canvas"
          style={{ transform: 'scale(1)' }}
        >
          {/* O template DEVE renderizar:
              <div id="cv-page" className="page abnt|modern" data-template="abnt|modern"> ... </div> */}
          <ResumePreview template={template} />
        </div>
      </div>
    </section>
  );
}
