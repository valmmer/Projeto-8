// src/components/preview/templates/ClassicABNT.tsx
// Clássico ABNT — 1 coluna, Times 12pt, entrelinha 1.5, recuo 1.25cm.
// O estilo e as margens vêm do print.css (.page.abnt + @page abnt).

import { useResume } from '../../../state';
import type { Skill } from '../../../types';

type SkillLevel = 'Básico' | 'Intermediário' | 'Avançado';
const LEVEL_ORDER: Record<SkillLevel, number> = {
  Avançado: 0,
  Intermediário: 1,
  Básico: 2,
};

// chave estável para listas
function keyOf(val: any, fallback: string, i: number) {
  return val?.id ?? `${fallback}-${i}`;
}

export default function ClassicABNT() {
  const { state } = useResume();
  const { dados, skills, experiencias, formacoes, certificacoes, idiomas } =
    state;

  const objetivo = (dados as any)?.objetivo?.trim();

  // 1 linha por informação de contato (facilita leitura/ATS)
  const contactLines = [
    dados.email?.trim() ? `E-mail: ${dados.email.trim()}` : null,
    dados.telefone?.trim() ? `Telefone: ${dados.telefone.trim()}` : null,
    dados.linkedin?.trim() ? `LinkedIn: ${dados.linkedin.trim()}` : null,
    (dados as any)?.github?.trim()
      ? `GitHub: ${(dados as any).github.trim()}`
      : null,
    dados.site?.trim() ? `Site/Portfólio: ${dados.site.trim()}` : null,
    dados.cidadePais?.trim() ? `Cidade/País: ${dados.cidadePais.trim()}` : null,
  ].filter(Boolean) as string[];

  // Ordena Hard/Soft, nível e nome
  const sorted = [...skills].sort((a: any, b: any) => {
    const byType = (a.tipo === 'Soft' ? 1 : 0) - (b.tipo === 'Soft' ? 1 : 0);
    if (byType !== 0) return byType;
    const byLvl = (LEVEL_ORDER as any)[a.nivel] - (LEVEL_ORDER as any)[b.nivel];
    if (byLvl !== 0) return byLvl;
    return a.nome.localeCompare(b.nome, 'pt', { sensitivity: 'base' });
  });
  const hard = sorted.filter((s: any) => s.tipo !== 'Soft');
  const soft = sorted.filter((s: any) => s.tipo === 'Soft');

  // Lista de skills (usa UL padrão do CSS ABNT)
  const SkillList = ({ items }: { items: Skill[] }) =>
    items.length ? (
      <ul>
        {items.map((s, i) => (
          <li key={keyOf(s, `skill-${s.nome}`, i)}>
            <p className="no-indent">
              {s.nome}
              {s.nivel ? (
                <>
                  {' '}
                  — <i>{s.nivel}</i>
                </>
              ) : null}
            </p>
          </li>
        ))}
      </ul>
    ) : (
      <p className="no-indent">—</p>
    );

  return (
    <div id="cv-page" className="page abnt" data-template="abnt">
      {/* =========================
          Cabeçalho (foto + dados)
          ========================= */}
      <header className="keep-with-next">
        <div className="header-grid">
          {dados.foto?.trim() ? (
            <img
              src={dados.foto}
              alt={dados.nome || 'Foto'}
              className="photo"
              crossOrigin="anonymous"
              referrerPolicy="no-referrer"
              loading="eager"
            />
          ) : (
            <div
              className="photo"
              style={{
                width: '32mm',
                height: '32mm',
                border: '0.5pt solid #cbd5e1',
                borderRadius: '2mm',
                display: 'grid',
                placeItems: 'center',
                color: '#64748b',
                fontSize: '10pt',
                background: '#fff',
              }}
            >
              Sem foto
            </div>
          )}

          <div>
            {/* Nome em destaque (o CSS da ABNT define tamanho/peso) */}
            <h1>{dados.nome || 'Seu Nome'}</h1>

            {/* Título profissional opcional */}
            {(dados as any)?.titulo?.trim() && <h2>{(dados as any).titulo}</h2>}

            {/* Linhas de contato (sem recuo) */}
            <div className="contact-lines">
              {contactLines.map((line, i) => (
                <p key={`contact-${i}`} className="no-indent">
                  {line}
                </p>
              ))}
            </div>
          </div>
        </div>
        <hr />
      </header>

      {/* ========== Resumo ========== */}
      <section className="keep-with-next">
        <h3 className="sec">RESUMO PROFISSIONAL</h3>
        <p className="no-indent">
          {dados.resumo || 'Adicione um resumo profissional...'}
        </p>
      </section>

      {/* ========== Objetivo (opcional) ========== */}
      {objetivo && (
        <section className="keep-with-next">
          <h3 className="sec">OBJETIVO PROFISSIONAL</h3>
          <p className="no-indent">{objetivo}</p>
        </section>
      )}

      {/* ========== Experiência ========== */}
      <section className="keep-with-next">
        <h3 className="sec">EXPERIÊNCIA PROFISSIONAL</h3>
        {state.experiencias.length ? (
          <div>
            {state.experiencias.map((e, i) => (
              <div
                className="entry no-split"
                key={keyOf(e, `exp-${e.empresa}-${e.cargo}`, i)}
              >
                <p className="no-indent">
                  <b>{e.cargo}</b> — {e.empresa}
                </p>
                <p className="no-indent">
                  <i>
                    {e.periodo}
                    {e.atual ? ' (atual)' : ''}
                  </i>
                </p>
                <p>{e.descricao}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-indent">Adicione suas experiências…</p>
        )}
      </section>

      {/* ========== Formação ========== */}
      <section className="keep-with-next">
        <h3 className="sec">FORMAÇÃO ACADÊMICA</h3>
        {formacoes.length ? (
          <div>
            {formacoes.map((f, i) => (
              <div
                className="entry no-split"
                key={keyOf(f, `edu-${f.curso}-${f.instituicao}`, i)}
              >
                <p className="no-indent">
                  <b>{f.curso}</b> — {f.instituicao}
                  {f.periodo ? ` · ${f.periodo}` : ''}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-indent">Adicione suas formações…</p>
        )}
      </section>

      {/* ========== Certificações ========== */}
      <section className="keep-with-next">
        <h3 className="sec">CERTIFICAÇÕES</h3>
        {certificacoes.length ? (
          <div>
            {certificacoes.map((c, i) => (
              <div
                className="entry no-split"
                key={keyOf(c, `cert-${c.titulo}`, i)}
              >
                <p className="no-indent">
                  {c.titulo}
                  {c.orgao ? ` — ${c.orgao}` : ''}
                  {c.ano ? ` · ${c.ano}` : ''}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-indent">Adicione suas certificações…</p>
        )}
      </section>

      {/* ========== Habilidades ========== */}
      <section className="keep-with-next">
        <h3 className="sec">HABILIDADES</h3>
        <div>
          <h4 className="sub no-indent">Hard Skills</h4>
          <SkillList items={hard as any} />
        </div>
        <div>
          <h4 className="sub no-indent">Soft Skills</h4>
          {soft.length ? (
            <ul>
              {soft.map((s, i) => (
                <li key={keyOf(s, `soft-${s.nome}`, i)}>
                  <p className="no-indent">{s.nome}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="no-indent">—</p>
          )}
        </div>
      </section>

      {/* ========== Idiomas ========== */}
      <section className="keep-with-next">
        <h3 className="sec">IDIOMAS</h3>
        {idiomas.length ? (
          <div>
            {idiomas.map((l, i) => (
              <div
                className="entry no-split"
                key={keyOf(l, `lang-${l.idioma}`, i)}
              >
                <p className="no-indent">
                  {l.idioma} — <i>{l.nivel}</i>
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-indent">Adicione seus idiomas…</p>
        )}
      </section>
    </div>
  );
}
