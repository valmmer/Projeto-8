// src/main.tsx
import './components/InputField'; // ⬅️ importe PRIMEIRO

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import './print.css';

const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
} else {
  console.error('Elemento #root não encontrado');
}
