// src/lib/serverPrint.ts

const PRINT_API = (import.meta as any)?.env?.VITE_PRINT_API || '/api/print/pdf';

function wrapHtml(inner: string) {
  // <base> garante resolução de /src/print.css, imagens e fontes
  const base = `${location.origin}/`;
  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<base href="${base}">
<link rel="stylesheet" href="/src/print.css">
</head>
<body>
${inner}
</body>
</html>`;
}

/**
 * Gera PDF no servidor. Por padrão envia somente o #cv-page.
 * Se `forceUrl: true`, envia a URL completa (requer @media print ocultando o resto).
 */
export async function downloadServerPDF(
  fromUrl?: string,
  opts?: { fileName?: string; selector?: string; forceUrl?: boolean },
) {
  const sel = opts?.selector ?? '#cv-page';
  const el = document.querySelector(sel) as HTMLElement | null;

  const useHtml = !opts?.forceUrl && !!el;
  const body = useHtml
    ? { html: wrapHtml(el!.outerHTML), fileName: opts?.fileName }
    : { url: fromUrl ?? location.href, fileName: opts?.fileName };

  const res = await fetch(PRINT_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error('Falha ao gerar PDF no servidor');

  const blob = await res.blob();
  const href = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = href;
  a.download = `${(opts?.fileName || document.title || 'curriculo').replace(
    /\.pdf$/i,
    '',
  )}.pdf`;
  a.click();
  URL.revokeObjectURL(href);
}
